// Client that sends the code to the server for verification
const input = document.getElementById('codeInput');
const btn = document.getElementById('submitBtn');
const msg = document.getElementById('msg');

btn.addEventListener('click', tryCode);
input.addEventListener('keydown', (e) => { if(e.key === 'Enter') tryCode(); });

async function tryCode(){
  msg.textContent = '';
  const code = (input.value || '').trim();
  if(!code){ msg.textContent = 'Please enter a code.'; return; }
  try{
    const r = await fetch('/api/check-code', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ code })
    });
    const j = await r.json().catch(()=>({}));
    if(r.ok && j.ok){
      // redirect to portal (server will allow it thanks to cookie)
      window.location.href = j.redirect || '/portal.html';
    } else {
      msg.textContent = j.message || 'Invalid code';
    }
  }catch(err){
    msg.textContent = 'Network error';
    console.error(err);
  }
}