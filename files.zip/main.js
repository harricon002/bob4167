// Client-only access check (not secure — codes are visible in JS)
const allowedCodes = [
  // Example codes: change to whatever you want for a lightweight gate
  "GAMEDOORBETA",
  "INVITE-123",
  "PLAY2025"
];

const input = document.getElementById('codeInput');
const btn = document.getElementById('submitBtn');
const msg = document.getElementById('msg');

btn.addEventListener('click', tryCode);
input.addEventListener('keydown', (e) => { if(e.key === 'Enter') tryCode(); });

function tryCode(){
  const v = (input.value || '').trim();
  if(!v){ msg.textContent = 'Please enter a code.'; return; }
  if(allowedCodes.includes(v)){
    // successful: redirect to the real site / portal
    // Use a relative path to the actual portal page (portal.html)
    window.location.href = '/portal.html';
  } else {
    msg.textContent = 'Invalid code.';
    input.classList.add('shake');
    setTimeout(()=>input.classList.remove('shake'),500);
  }
}